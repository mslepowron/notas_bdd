  /*
   1. obtener el padron y el apellido de el/los alumno/s que tena/n la mayor
   cantidad de materias aprobadas
*/
   
select a.padron, a.apellido
from ALUMNOS A join NOTAS N1 on a.PADRON = n1.PADRON
join NOTAS n2 on n1.codigo = n2.CODIGO and n1.numero = n2.numero
where n1.NOTA >=4 and n1.nota > n2.nota
group by a.padron, n1.codigo, n1.NUMERO 
having count(1) >= all (
				select count(1) 
				from NOTAS N1
				group by n1.padron
				)			
				
-- Resultados --
				
-- padron|apellido|
-- ------+--------+
--  73000|Molina  |
--  86000|Díaz    |