/*
 * 6. Listar el padron de aquellos alumnos que, por lo menos, tiene nota en todas
 * las materias que aprobo el alumno de padron 71000
 */

select distinct PADRON 
from notas n
where to_char(n.codigo, 'fm00')|| '.' || to_char(n.numero,'fm00') in (
		select to_char(n1.codigo, 'fm00')|| '.' || to_char(n1.numero,'fm00')
		from notas n1
		where n1.padron = 71000 and n1.nota >= 4)
and padron <> 71000;		
    
-- Resultados --

--	padron|
--	------+
--	 72000|
--	 73000|
--	 75000|
--	 86000|
--	 87000|
--	 88000|