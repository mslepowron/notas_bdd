/*
   5. Para cada nota del alumno mas antiguo, mostrar su padron,
   codigo de depto, numero de materia y el valor de la nota
*/

select a.padron, n.codigo, n.numero, n.nota
from alumnos A join NOTAS N on a.padron = n.padron
where a.FECHA_INGRESO = (select MIN(a.FECHA_INGRESO)
						 from ALUMNOS A)

-- Resultados --
	
--	padron|codigo|numero|nota|
--	------+------+------+----+
--	 71000|    75|     1|   4|
--	 71000|    75|     6|   2|
--	 71000|    75|     6|   6|
--	 71000|    71|    14|   7|
	