/*
 * 2. Obtener el padron y apellido de los alumnos que tienen nota en las materias 71.14 y 71.15
 * y no tienen nota ni el la materia 75.01 ni en 75.15
 */   
   
select distinct a.padron, a.apellido
from ALUMNOS A join NOTAS N on a.PADRON = n.PADRON
where n.CODIGO = 71 and N.NUMERO = 14 
and a.PADRON in (select PADRON 
				   from NOTAS n1 
				   where n1.CODIGO = 71 and n1.NUMERO = 15)
and A.PADRON not in (select PADRON 
				   		from NOTAS n2
				  		where n2.CODIGO = 75 and n2.NUMERO = 1)
and A.PADRON not in (select PADRON 
				   		from NOTAS n3
				  		where n3.CODIGO = 75 and n3.NUMERO = 15);	

				  	
-- Resultados --
				  	
--	padron|apellido|
--	------+--------+
-- 	86000 |Díaz    |	
				  		