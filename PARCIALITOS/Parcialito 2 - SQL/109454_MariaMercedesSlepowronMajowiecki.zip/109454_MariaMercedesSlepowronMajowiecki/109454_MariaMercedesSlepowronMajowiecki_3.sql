
/*
   3. Se necesita saber el promedio general para cada carrera y cada departamento.
   Devolviendo el codigo de carrera, codigo de depto y el promedio de notas para todos los alumnos
   de cada depto, ordenados por carrera y departamento
*/
   
select ie.codigo as codigo_carrera, n.codigo as codigo_deptartamento, AVG(n.nota) as promedio
from NOTAS N join INSCRIPTO_EN IE on n.PADRON = ie.PADRON 
group by ie.CODIGO, n.codigo
order by ie.codigo, n.codigo;

-- Resultados --

-- codigo_carrera|codigo_departamento|promedio          |
-- --------------+-------------------+------------------+
--              5|                 61|7.0000000000000000|
--              5|                 62|7.2500000000000000|
--              6|                 61|8.8000000000000000|
--              6|                 62|7.0000000000000000|
--              9|                 71|6.7142857142857143|
--              9|                 75|6.6923076923076923|
--             10|                 71|6.7500000000000000|
--             10|                 75|6.5000000000000000|
	